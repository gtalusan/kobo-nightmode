#!/bin/sh

echo "t" > /tmp/invertScreen
